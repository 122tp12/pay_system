﻿using Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using users;
using System.Data.SqlClient;
using pay_system;
namespace aftore
{
    internal partial class transfer : Form
    {
        void update(user u)
        {
            try
            {

                using (SqlConnection sql = new SqlConnection(@"Data Source=NOTEBOOK\SQLEXPRESS;Initial Catalog=MiniBank;Integrated Security=True"))
                {
                    sql.Open();
                    string sqlExpression;
                    sqlExpression = "update [user] set balance= " + u.balance + " where id=" + u.id;

                    SqlCommand command = new SqlCommand(sqlExpression);

                    command.Connection = sql;

                    command.ExecuteNonQuery();

                    sql.Close();


                }
            }
            catch (Exception e)
            {
                MessageBox.Show($"{e} Exception caught.", "Error sql");
            }
        }
        Form4 f;
        user u;
        public transfer(Form4 _f, ref user _u)
        {
            f = _f;
            u = _u;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float ma = float.Parse(textBox1.Text);
            string num = textBox2.Text;
            
            user m = new user();
            try
            {
                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=MiniBank;Integrated Security=True";

                SqlConnection connection = new SqlConnection(connectionString);


                string sqlExpression = "SELECT * FROM [user]";
                // Открываем подключение
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                SqlDataReader reader = command.ExecuteReader();
                
                if (reader.HasRows) // если есть данные
                {
                    // выводим названия столбцов

                    while (reader.Read()) // построчно считываем данные
                    {
                        object f1 = reader.GetValue(0);
                        //object f2 = reader.GetValue(1);
                        //object f3 = reader.GetValue(2);
                        //object f4 = reader.GetValue(3);
                        //object f5 = reader.GetValue(4);
                        object f6 = reader.GetValue(5);
                        object f7 = reader.GetValue(6);
                        object f8 = reader.GetValue(7);
                        //object f9 = reader.GetValue(8);
                        
                        //f2 = addingFunk.dellSpace(f2);
                        //f3 = addingFunk.dellSpace(f3);
                        f7 = addingFunk.dellSpace(f7);
                        //f4 = addingFunk.dellSpace(f4);
                        //f5 = addingFunk.dellSpace(f5);
                        f6 = addingFunk.dellSpace(f6);
                        
                        if (Convert.ToString(f7) == num )
                        {
                            
                                reader.Close();
                                m.id = Convert.ToInt32(f1);
                               // m.name = Convert.ToString(f2);
                               // m.surName = Convert.ToString(f3);
                                //m.email = Convert.ToString(f4);
                                //m.telephone = f5.ToString();
                                m.password = Convert.ToString(f6);
                                m.numOfCard = Convert.ToString(f7);
                               m.balance = Convert.ToDouble(f8);
                            
                                
                                
                                connection.Close();
                                reader.Close();
                            break;
                            
                        }
                    
                    }


                }
                reader.Close();
                connection.Close();


            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.ToString(), "Exception caught.");


            }
            if (u.balance < ma)
            {
                MessageBox.Show("Not enoth many", "Error");
            }
            else
            {
                u.balance -= ma;
                m.balance += ma;
                update(u);
                update(m);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            f.Visible = true;
            this.Close();
        }
    }
}
