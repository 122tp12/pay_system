﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using users;
using Framework;
namespace aftore
{
    internal partial class EditP : Form
    {
        public void fillG() {
            try
            {
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.ReadOnly = true;

                using (SqlConnection sql = new SqlConnection(@"Data Source=NOTEBOOK\SQLEXPRESS;Initial Catalog=MiniBank;Integrated Security=True"))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter($"select id, datePay, many, interval from payment where id_user=" + u.id, sql);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0];
                    dataGridView1.Columns[2].Width = 100;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }
        user u;
        Form4 f;
        public EditP(Form4 _f,user _u)
        {
            f = _f;
            u = _u;
            InitializeComponent();
            fillG();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(textBox1.Text);
            try
            {

                using (SqlConnection sql = new SqlConnection(@"Data Source=NOTEBOOK\SQLEXPRESS;Initial Catalog=MiniBank;Integrated Security=True"))
                {
                    sql.Open();
                    SqlCommand com = new SqlCommand("DELETE FROM payment WHERE id_user=" + u.id, sql);
                    com.ExecuteNonQuery();
                    sql.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            fillG();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            f.Visible = true;
            this.Close();
        }
    }
}
