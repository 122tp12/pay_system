﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using users;
using pay_system;
using aftore;
using System.Data.SqlClient;

namespace Framework {
	internal partial class Form4: Form {
        static void SetRoundedShape(Control control, int radius)
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddLine(radius, 0, control.Width - radius, 0);
            path.AddArc(control.Width - radius, 0, radius, radius, 270, 90);
            path.AddLine(control.Width, radius, control.Width, control.Height - radius);
            path.AddArc(control.Width - radius, control.Height - radius, radius, radius, 0, 90);
            path.AddLine(control.Width - radius, control.Height, radius, control.Height);
            path.AddArc(0, control.Height - radius, radius, radius, 90, 90);
            path.AddLine(0, control.Height - radius, 0, radius);
            path.AddArc(0, 0, radius, radius, 180, 90);
            control.Region = new Region(path);
        }
        Form3 f;
		user u;
		public Form4(Form3 f3, user _u) {
			InitializeComponent();
            SetRoundedShape(panel1, 50);
			f = f3;
			u = _u;
			name.Text =  addingFunk.dellSpace(u.name) + " " + addingFunk.dellSpace(u.surName);
			card.Text = u.numOfCard;
			telephone.Text=u.telephone;
			email.Text=u.email;
            date.Text = u.dateTo.Day.ToString() + "/" + u.dateTo.Month.ToString();
			balance.Text = u.balance.ToString();

            using (SqlConnection sql=new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=MiniBank;Integrated Security=True"))
            {
                sql.Open();
                SqlCommand com = new SqlCommand("UPDATE payment SET datePay = datePay + interval WHERE getdate()>datePay and id_user = " + u.id, sql);
                int a=com.ExecuteNonQuery();
                sql.Close();
            }
        }
		
		private void button3_Click(object sender, EventArgs e)
        {
			f.Visible = true;
			this.Close();
        }

        private void telephone_Click(object sender, EventArgs e)
        {

        }

        private void balance_Click(object sender, EventArgs e)
        {

        }

        private void card_Click(object sender, EventArgs e)
        {

        }

        private void email_Click(object sender, EventArgs e)
        {

        }

        private void date_Click(object sender, EventArgs e)
        {

        }

        private void name_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {


            this.Visible = false;

                Form7 form = new Form7(ref u, this);

                form.Show();

            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            transfer t = new transfer(this, ref u);
            t.Show();
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            EditP f = new EditP(this, u);
            this.Visible = false;
            f.Show();
        }

        public bool refresh(ref user m)
        {
            try
            {
                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=MiniBank;Integrated Security=True";

                SqlConnection connection = new SqlConnection(connectionString);


                string sqlExpression = "SELECT * FROM [user]";
                // Открываем подключение
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows) // если есть данные
                {
                    
                    // выводим названия столбцов

                    while (reader.Read()) // построчно считываем данные
                    {
                        object f1 = reader.GetValue(0);
                        object f2 = reader.GetValue(1);
                        object f3 = reader.GetValue(2);
                        object f4 = reader.GetValue(3);
                        object f5 = reader.GetValue(4);
                        object f6 = reader.GetValue(5);
                        object f7 = reader.GetValue(6);
                        object f8 = reader.GetValue(7);
                        object f9 = reader.GetValue(8);

                        f2 = addingFunk.dellSpace(f2);
                        f3 = addingFunk.dellSpace(f3);
                        f7 = addingFunk.dellSpace(f7);
                        f8 = addingFunk.dellSpace(f8);
                        f4 = addingFunk.dellSpace(f4);
                        f5 = addingFunk.dellSpace(f5);
                        f6 = addingFunk.dellSpace(f6);

                        if (Convert.ToInt32(f1) == u.id)
                        {
                            
                                reader.Close();
                                m.id = Convert.ToInt32(f1);
                                m.name = Convert.ToString(f2);
                                m.surName = Convert.ToString(f3);
                                m.email = Convert.ToString(f4);
                                m.telephone = f5.ToString();
                                m.password = Convert.ToString(f6);
                                m.numOfCard = Convert.ToString(f7);
                                m.balance = Convert.ToDouble(f8);
                                int tmp = Convert.ToInt32(f1);

                                sqlExpression = "SELECT * FROM Keashbeak";
                                // Открываем подключение
                                command = new SqlCommand(sqlExpression, connection);
                                reader = command.ExecuteReader();
                                while (reader.Read()) // построчно считываем данные
                                {
                                    f1 = reader.GetValue(0);
                                    f2 = reader.GetValue(1);
                                    f3 = reader.GetValue(2);
                                    f4 = reader.GetValue(3);
                                    f5 = reader.GetValue(4);
                                    f6 = reader.GetValue(5);
                                    f7 = reader.GetValue(6);
                                    f8 = reader.GetValue(7);
                                    f9 = reader.GetValue(8);
                                    object f10 = reader.GetValue(9);
                                    object f11 = reader.GetValue(10);
                                    object f12 = reader.GetValue(11);
                                    object f13 = reader.GetValue(12);
                                    if (Convert.ToInt32(f1) == tmp)
                                    {
                                        KashBeak tmp1 = new KashBeak();
                                        tmp1.procent = Convert.ToInt32(f2);
                                        tmp1.name = reader.GetName(1);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f3);
                                        tmp1.name = reader.GetName(2);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f4);
                                        tmp1.name = reader.GetName(3);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f5);
                                        tmp1.name = reader.GetName(4);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f6);
                                        tmp1.name = reader.GetName(5);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f7);
                                        tmp1.name = reader.GetName(6);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f8);
                                        tmp1.name = reader.GetName(7);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f9);
                                        tmp1.name = reader.GetName(8);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f10);
                                        tmp1.name = reader.GetName(9);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f11);
                                        tmp1.name = reader.GetName(10);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f12);
                                        tmp1.name = reader.GetName(11);
                                        m.KashBeaks.Add(tmp1);
                                        tmp1.procent = Convert.ToInt32(f13);
                                        tmp1.name = reader.GetName(12);
                                        m.KashBeaks.Add(tmp1);
                                    }
                                }
                                connection.Close();
                                reader.Close();

                                return true;
                            
                        }
                    }



                }
                reader.Close();
                connection.Close();


                return false;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Exception caught.");

                return false;

            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            refresh(ref u);
            name.Text = addingFunk.dellSpace(u.name) + " " + addingFunk.dellSpace(u.surName);
            card.Text = u.numOfCard;
            telephone.Text = u.telephone;
            email.Text = u.email;
            date.Text = u.dateTo.Day.ToString() + "/" + u.dateTo.Month.ToString();
            balance.Text = u.balance.ToString();
        }
    }
}
